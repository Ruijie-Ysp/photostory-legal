# 地理实体数据（考据层）

`GeoFeatureIndex` 的随包数据。由 `Scripts/fetch-osm-features.py`（抓 OSM 原始响应）
与 `Scripts/make-feature-bundle.py`（裁剪/简化/生成）产出（幂等，可重跑）。

| 文件 | 内容 | 要素数 | 体量 | 来源 | 许可 |
|---|---|---|---|---|---|
| `lakes.geojson` | 产品区域（26–38°N / 74–104°E）内有名字的湖泊（**面**） | 1,622 | 1.0 MB | **OpenStreetMap**（Overpass，`natural=water` / `water=lake\|reservoir`） | **ODbL 1.0** |
| `rivers.geojson` | 区域内命名河流（**线**，全球骨架，16,311 顶点） | 51 | 298 KB | Natural Earth 10m `ne_10m_rivers_lake_centerlines` | **公有领域** |
| `rivers-osm.geojson` | 区域命名河流（**线**，同名相接的 way 合并成整条河） | 4,503 | 3.3 MB | **OpenStreetMap**（Overpass，`waterway=river\|stream\|canal`） | **ODbL 1.0** |
| `glaciers.geojson` | 命名冰川（**面**）：OSM `natural=glacier` + RGI 6.0 真名要素 | 852 | 2.8 MB | OpenStreetMap + **RGI 6.0** | ODbL 1.0 + **CC BY 4.0** |
| `protected-areas.geojson` | 命名保护区（**面**），中文名**逐字保留** | 178 | 167 KB | **OpenStreetMap**（`boundary=protected_area\|national_park`、`leisure=nature_reserve`） | **ODbL 1.0** |
| `river-names.tsv` | NE 河流的中文名对照表（**人工维护/审阅**，不是脚本生成的） | 29 行 | 9 KB | GeoNames CN dump（CC BY 4.0）+ 人工判定 | 逐行标了 `geonameid` |
| `peaks.geojson` | 西藏山峰（含 `ele` 1,385 / 中文名 734 / 藏文名 126） | 4,869 | 992 KB | OpenStreetMap relation 153292 | **ODbL 1.0** |
| `passes.geojson` | 西藏垭口（`mountain_pass=yes`） | 468 | 118 KB | 同上 | ODbL 1.0 |
| `viewpoints.geojson` | 西藏观景台（`tourism=viewpoint`） | 181 | 34 KB | 同上 | ODbL 1.0 |

> 各文件的精确要素数/体积/顶点数以 `python3 Scripts/make-feature-bundle.py` 的输出为准
> （本表是换源后第一次生成（2026-10-10）的实测值，抓取范围扩大会让数字继续增长）。
> 八份数据文件 + 中文名对照表合计 **8.9 MB**（换源前 1.5 MB；App 现有 GeoNames 数据约 39 MB）。
> 换源后索引里的要素总数是 **9,852**（换源前 5,594）。

## 为什么换源：覆盖率

`GeoFeatureIndex` 的价值**全在覆盖面**上。旧数据源（Natural Earth 10m）是全球尺度产品：
全球 1,355 个湖里落在产品区域的只有 25 个，西藏全境 3,825 个网格抽样点里
**只有 9.0% 的点的 50 km 内能找到一个有名字的湖** —— 而西藏 >1 km² 的湖有一千多个。
湖就在那里，产品说不出名字。河流同理：51 条（NE 只收世界级大河）覆盖 25.4%。

换源后的实测覆盖率见 `Tests/GeoFactsCoreTests/CoverageProbe.swift`（同一条探针）：

| 类别 | 换源前 | 换源后（2026-10-10 实测） |
|---|---|---|
| 至少命中一个地物 | 77.7% | **98.9%** |
| **一个地物都没有的点** | **22.3%** | **1.1%** |
| 湖 | 9.0% | **69.8%** |
| 河流 | 25.4% | **81.3%** |
| 山峰 | 65.9% | 64.7%（数据未动；是"更丰富的结果列表挤占"的 1 个百分点） |
| 垭口 | 4.8% | 4.3%（同上） |
| 观景台 | 0.6% | 0.6% |
| 冰川 | —（无数据） | **11.5%** |
| 保护区 | —（无数据） | **59.2%** |

探针的"命中"定义是 `lookup().deduplicated` 里出现过该类地物（列表上限 16 条）——
所以上面的小回落不是数据变薄，而是同一条列表里挤进了更值得提的地物（河/湖/保护区）。

## 裁剪/派生规则

### OSM 面图层（湖 / 冰川 / 保护区，`Scripts/osm_features.py`）

1. **丢掉无名字的要素**——卡片提不出名字的水体/保护区是纯负担；
2. 关系（multipolygon）按**端点精确拼接**成环；缺口 > 200 m 的环作废并计数（宁少勿假）；
3. Douglas-Peucker 简化：湖 **60 m**、冰川 150 m、保护区 300 m。
   60 m 的容差不会改变「你在不在岸上」这类判断（岸线容差本身是 250 m），
   但把 2,481 顶点的拉昂错压到 261 个（实测）；
4. 坐标保留 4 位小数（约 11 m），连续重合点合并；外环逆时针、洞顺时针（GeoJSON 规范）；
5. 面积阈值：湖 ≥ 0.02 km²（2 公顷）、冰川 ≥ 0.1 km²、保护区 ≥ 1 km²。
   2 公顷以下的命名水塘在区域内有两千多个（印度/尼泊尔低地的村塘为主），
   它们的证言价值远不及字节成本 —— 阈值是**明确取舍**，不是漏抓；
6. `water=river|stream|canal` 的面**排除出湖泊层**（OSM 里确有把河段画成水面的，
   实测一条标成「雅鲁藏布江」的 27 KB 面）；河属于河流层；
7. 每个要素带 `osm` 属性（OSM 元素号，如 `r7520197`），Swift 侧写进
   `NamedFeature.source`，可回查 openstreetmap.org。

### OSM 河流层（`build_osm_rivers`）

1. **按「同名 + 端点相接」合并**（并查集）：OSM 的一条河是几十上百个 way 片段，
   不合并的话「雅鲁藏布江」会变成几十条各自几公里的要素 —— 卡片说不出"这是哪条江"，
   长度也没法当重要性信号。不同河重名很常见（西藏一堆「那曲」/「扎曲」），
   但同名的两条不同河在地理上不相接 —— 两个条件同时成立才合并，口径是**宁可少合并**；
2. 合并后短于 **2 km** 的丢弃（"沟"不是卡片里说得出口的地物）；
3. 水系关系（`type=waterway` relation）**不参与几何**：实测本区域的关系既稀疏
   又与 way 重复，且关系成员往往只是一个河段的一部分。统计里报出跳过数量备查。

### 名字与中文名

- **OSM 名字就是中文名**（境内要素的 `name` 常是「藏文 + 中文」混排，如
  `拉昂错 ལ་ལྔ་མཚོ།`）：Swift 侧 `FeatureNaming.openStreetMap` 的优先级是
  `name:zh-Hans` → `name` 里的汉字段 → `name:zh` → `name:en`/`int_name`/`name`（拉丁兜底），
  路径写进 `source`；
- **保护区中文名逐字保留**：`雅鲁藏布大峡谷国家级自然保护区` 这类官方名不做任何翻译/改写；
- **CN.txt 交叉核对**（`annotate_cn_records`）：CN 记录的中文别名与要素名字**逐字相等**时
  才写 `cn`（geonameid）；CN 记录的点作为**交叉核对**（湖/冰川/保护区要求点落在面内，
  河流要求点距线 < 20 km），名字不匹配的一律不链接 —— 被禁止的做法是"点很近就把名字安上去"；
- **RGI 冰川的名字**：中国境内的 RGI 名多是冰川编目号（`CN5K413D0005`），**那不是名字**，
  不收录；只有带真实地名的（`Gangotri Glacier`、`Baishui River No1 Glacier`）才进包，
  来源写成 `rgi-6.0/<RGIId>`（拉丁名，没有中文名时就显示它 —— 这是"标准名回退"）。

### NE 河流为什么保留

`rivers.geojson`（NE 10m，51 条）继续随包，作为**全球骨架**：

1. 区域外的河流（境内 OSM 抓取范围是 76–101°E / 25–38°N，见下）由它兜底；
2. 人工审阅的中文名对照表（`river-names.tsv`）与它绑定，那是逐行核对过的证据链
   （`--audit` 会重新核对，测试侧 `RiverFeatureTests` 也逐行复核）；
3. 它的 `name` 是拉丁名 → 中文名的映射，`雅鲁藏布江` 这类名字的来源写得清清楚楚。

两层河流在查询结果里会同时出现（同一条江两个要素）。**显示层**的
`FeatureFacts.deduplicated` 已经把同类别、空间相距 < 5 km 的重复合并
（这是既有机制，针对"纳木那尼峰 7694/6912"那类重复设计的），所以卡片不会说两遍。

## 抓取范围与已知缺口（如实记录）

- 湖 / 冰川 / 保护区：产品区域 74–104°E / 26–38°N；
- **河流：76–101°E / 25–38°N**（比产品区域小一圈）。原因：Overpass 主站在生产会话里
  持续限流（429）/超时（504）、`kumi.systems` 与 `private.coffee` 返回 500、
  `overpass.osm.ch` 是**瑞士专用实例**（对西藏静默返回 0 个元素 —— 这种"静默空响应"
  比报错更危险，已从镜像列表里剔除）、Geofabrik 在本机网络不可达（连接超时）。
  在"抓不完"的前提下，预算优先花在西藏（`--priority 78,26,99,37`）；区域外的河流
  由 NE 层兜底。抓取原始响应逐文件落盘在 `.geofacts-data/osm/raw/overpass/`，可续跑、可审计。
- **RGI 7.0 无法免登录下载**（NSIDC 需要 Earthdata 账号，实测返回 HTML 登录页），
  因此冰川用 RGI 6.0（OGGM 公开镜像，`Scripts/fetch-rgi.sh`）。中国境内的 RGI 冰川
  几乎全是编目号、没有地名 —— 所以**米堆/来古/绒布这些冰川的名字只能来自 OSM**，
  RGI 的贡献是喜马拉雅南坡（尼泊尔/印度一侧）的英文名冰川与几何补充。

## 河流中文名对照表（river-names.tsv，NE 层用）

规则与"被禁止的做法"见文件头与 `Scripts/make-feature-bundle.py --audit`：
中文名**逐字取自** GeoNames CN 记录（`cn.txt` 行）或人工判定（`curated` 行），
链接靠**名字**（NE 名 == 记录名，或记录名去掉 He/Ho/Jiang/Zangbo/Qu 等水名词尾后的核心名），
距离只作交叉核对。**禁止**拿地理上靠近的 CN.txt 河流点按"离得近"把名字安到 NE 线上。

## 复现

```bash
# ① OSM 原始响应（分块 + 多镜像 + 失败拆分，可反复重跑：已有的分块会跳过）
python3 Scripts/fetch-osm-features.py                 # 全部图层
python3 Scripts/fetch-osm-features.py --layer lakes   # 只抓湖泊
python3 Scripts/fetch-osm-features.py --only-priority # 只抓西藏（78,26,99,37）内的分块

# ② RGI 6.0 冰川（三个分区，约 120 MB）
bash Scripts/fetch-rgi.sh

# ③ 生成 features/（幂等；--audit 会逐行核对 river-names.tsv 并出错退出）
python3 Scripts/make-feature-bundle.py --audit
```

## 署名（分发前必须保留）

- OpenStreetMap：`© OpenStreetMap contributors`，许可 **ODbL 1.0**
  （https://www.openstreetmap.org/copyright）。**share-alike 提示**：把 OSM 派生数据
  打包成随 App 分发的数据库时，该数据库须以 ODbL 提供；仅作"产成品"（查询结果/渲染）
  使用则只需署名 —— 本层是"查询后给出结果"，`NamedFeature.source` 逐条带上了来源与元素号。
- Natural Earth：`Made with Natural Earth.`（公有领域，无强制署名要求）
- GeoNames CN dump：`GeoNames, CC BY 4.0`（中文名交叉核对逐条标了 `geonameid`，可回溯）
- **RGI 6.0（Randolph Glacier Inventory）**：数据由 GLIMS / RGI 工作组发布，许可
  **CC BY 4.0**。署名串：`Randolph Glacier Inventory 6.0 (RGI 6.0), a dataset of
  global glacier outlines, is provided by the GLIMS project / RGI consortium
  (https://www.glims.org/RGI/) under CC BY 4.0.`
  （RGI 数据随包分发的部分**只有**带真实地名的要素，逐条记 `rgi-6.0/<RGIId>`。）

## 随包体积与性能（release，2026-10-10 实测）

| 指标 | 换源前 | 换源后 |
|---|---|---|
| 本目录（`features/`） | 1.5 MB | **8.9 MB**（+7.3 MB） |
| 索引要素数 | 5,594 | **9,852** |
| 载入耗时（release，隔离） | 0.055 s | **0.430 s**（预算 0.5 s） |
| RSS（release，隔离；steady / peak） | 31 MB | **56 / 59 MB**（预算 60 MB） |
| 查询延迟（release，1000 次均值） | 17.7 µs | **302 µs** |

查询变慢的原因是几何从"以点为主"变成"以面/线为主"（200k+ 顶点要在剪枝后做点到线段
距离）。0.33 ms/次对"一张照片做一次查询"的用法完全够用；`.geofacts-data/README.md`
的 0.5 s / 60 MB 两条预算线都还有余量（约 25% / 5%）。简化容差就是按这两条线定的：
湖 150 m、河 300 m、冰川 350 m、保护区 800 m；`waterway=stream` 还要 ≥10 km 才收（见 `make-feature-bundle.py` 的常量）。
